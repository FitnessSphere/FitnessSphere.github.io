import React from 'react'

export default function Hero() {
  return (
    <section id="home" className="hero-bg pt-28 pb-12">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <div className="inline-block p-1 rounded-xl bg-gradient-to-r from-primary/30 to-accent/20 mb-6">
          <span className="text-xs uppercase px-3 py-1 font-semibold text-primary">New • Animated Template</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-extrabold mb-4 leading-tight fade-up" style={{animationDelay: '0.1s'}}>
          Modern, Premium Website — Ready to Edit
        </h1>

        <p className="text-gray-600 max-w-2xl mx-auto mb-6 fade-up" style={{animationDelay: '0.2s'}}>
          This starter includes smooth animations, a clean layout, and easy-to-replace sections so you can make a professional site without coding.
        </p>

        <div className="flex items-center justify-center gap-4 fade-up" style={{animationDelay: '0.3s'}}>
          <a href="#contact" className="px-6 py-3 rounded-lg bg-primary text-white font-semibold shadow hover:opacity-95 transition">Get Started</a>
          <a href="#about" className="px-6 py-3 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 transition">Learn More</a>
        </div>
      </div>
    </section>
  )
}
