import React from 'react'

export default function Header() {
  return (
    <header className="w-full fixed top-0 left-0 z-40 bg-white/80 backdrop-blur-sm">
      <div className="max-w-4xl mx-auto flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Logo" className="h-10 w-10 object-contain rounded-md shadow-sm" />
          <span className="font-semibold text-lg">YourSite</span>
        </div>

        <nav className="hidden sm:flex gap-6 text-sm font-medium text-gray-700">
          <a href="#home" className="hover:text-primary transition">Home</a>
          <a href="#about" className="hover:text-primary transition">About</a>
          <a href="#services" className="hover:text-primary transition">Services</a>
          <a href="#contact" className="hover:text-primary transition">Contact</a>
        </nav>

        <div className="sm:hidden text-gray-700">Menu</div>
      </div>
    </header>
  )
}
