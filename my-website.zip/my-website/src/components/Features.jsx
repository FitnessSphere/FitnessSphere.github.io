import React from 'react'

const items = [
  {title:'Fast & Lightweight', desc:'Built for speed and mobile-first performance.'},
  {title:'Easy to Edit', desc:'All text and images are in obvious files; replace and go.'},
  {title:'Responsive', desc:'Looks great on phones and desktops.'},
  {title:'Animated', desc:'Subtle animations that feel premium.'},
]

export default function Features() {
  return (
    <section id="services" className="py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-2xl font-bold mb-6">Features</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {items.map((it, i) => (
            <div key={i} className="card p-5 rounded-lg bg-white fade-up" style={{animationDelay: `${0.1 + i*0.05}s`}}>
              <h3 className="font-semibold mb-2">{it.title}</h3>
              <p className="text-sm text-gray-600">{it.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
