import React from 'react'

export default function About() {
  return (
    <section id="about" className="py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-2xl font-bold mb-4">About</h2>
        <p className="text-gray-700 mb-3">Write a short description about your site, your services, or yourself. Keep it friendly and direct.</p>
        <p className="text-gray-600">Tip: Replace this text in the file <code>src/components/About.jsx</code>.</p>
      </div>
    </section>
  )
}
