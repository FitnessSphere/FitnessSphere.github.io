import React from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Features from './components/Features'
import About from './components/About'
import Contact from './components/Contact'

export default function App(){
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24">
        <Hero />
        <Features />
        <About />
        <Contact />
      </main>

      <footer className="border-t mt-12">
        <div className="max-w-4xl mx-auto px-4 py-6 text-sm text-gray-500">
          © {new Date().getFullYear()} YourSite — Built with care. Edit files in <code>src/components</code>
        </div>
      </footer>
    </div>
  )
}
