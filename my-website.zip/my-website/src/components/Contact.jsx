import React from 'react'

export default function Contact() {
  return (
    <section id="contact" className="py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-2xl font-bold mb-4">Contact</h2>
        <p className="text-gray-700">Email: <a href="mailto:your@email.com" className="text-primary">your@email.com</a></p>
        <p className="text-gray-600 mt-2">Or replace this section with a contact form later.</p>
      </div>
    </section>
  )
}
